package com.DaoImpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.Dao.userDao;
import com.model.Product;
import com.model.User;

public class UserDaoImpl implements userDao {

	@Autowired 
	SessionFactory sessionFactory;

	@Autowired
	public UserDaoImpl(SessionFactory sessionFactory)
	{
	super();
	this.sessionFactory= sessionFactory;
	}


	public void insertUser(User user) 
	{
	Session session = sessionFactory.openSession();
	session.beginTransaction();
	session.saveOrUpdate(user); 
	session.getTransaction().commit();
	}
	
	public List<User> retrieve()
	{
		Session session = sessionFactory.openSession();
		
			session.beginTransaction();
			List<User> obj = session.createQuery("from User").list();
			session.getTransaction().commit();
			return obj;
			
		}
	 public User findById(int pid)
	  {

		  Session session = sessionFactory.openSession();
		  
		  User  s = null;
		  try
		  {  
			session.beginTransaction();
			s = session.get(User.class,pid);
			session.getTransaction().commit();
				  }
		  catch(Exception e)
		  {
			  session.getTransaction().rollback();
		  }
		  return s;
	  }
	
	 public List<User> getUserById(String email)
	 {
		 Session session= sessionFactory.openSession();
		List<User> user =null; ;
		session.beginTransaction();
		user=session.createQuery("from User where e_mail=" + email ).list();
			 session.getTransaction().commit();
			 return user;
		 
	 }

	 

}
