package com.Dao;

import com.model.Supplier;

public interface SupplierDao {

	public void insertSupplier(Supplier supplier);
}
