package com.Dao;

import com.model.Product;

public interface ProductDao {

	public void insertProduct(Product product);
}
