package com.Dao;

import com.model.User;

public interface userDao {

	public void insertUser(User user);
}
