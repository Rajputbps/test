package com.Dao;

import com.model.Category;

public interface categoryDao {
	
	public void insertCategory(Category category);

}
